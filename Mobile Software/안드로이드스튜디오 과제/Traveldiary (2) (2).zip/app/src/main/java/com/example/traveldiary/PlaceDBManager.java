package com.example.traveldiary;

// SQLite DB를 다루는 역할

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PlaceDBManager extends SQLiteOpenHelper {
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.disableWriteAheadLogging();
    } //https://nuggy875.tistory.com/28
    //https://6developer.com/944
    // no such table 오류 해결

    static final String PLACE_DB = "Places.db";
    static final String PLACE_TABLE = "Places";
    Context context = null;
    private static PlaceDBManager dbManager = null;

    static final String CREATE_DB = " CREATE TABLE IF NOT EXISTS " + PLACE_TABLE + " ( _id INTEGER PRIMARY KEY AUTOINCREMENT, " + " place_name TEXT NOT NULL, place_descrip TEXT NOT NULL, place_img STRING, place_lati DOUBLE, place_long DOUBLE);";
    // 위도 경도는 DOUBLE로 선언

    public static PlaceDBManager getInstance(Context context) {
        if (dbManager == null) {
            dbManager = new PlaceDBManager(context, PLACE_DB, null, 1);
        }
        return dbManager;
    }

    public PlaceDBManager(Context context, String dbName, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, dbName, factory, version);
        this.context = context;
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_DB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {

    }

    public long insert(ContentValues addValue) {
        return getWritableDatabase().insert(PLACE_TABLE, null, addValue);
    }

    public Cursor query(String[] columns, String selection, String[] selectionArgs,
                        String groupBy, String having, String orderBy) {
        return getReadableDatabase().query(PLACE_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
    }
    public int delete(String whereClause, String[] whereArgs){
        return getWritableDatabase().delete(PLACE_TABLE, whereClause, whereArgs);
    }

}

