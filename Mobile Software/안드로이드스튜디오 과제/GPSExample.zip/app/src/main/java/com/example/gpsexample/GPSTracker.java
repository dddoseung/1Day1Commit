package com.example.gpsexample;

import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class GPSTracker extends Service implements LocationListener {
    private final Context myContext;

    boolean isGPSEnabled = false;
    boolean isNetworkEnabled = false;
    boolean canGetGPSInfo = false;

    Location myLocation;
    double latitude;
    double longitude;

    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10; // meter
    private static final long MIN_TIME_UPDATES = 30000; // 0.5 minutes

    protected LocationManager myLocationManager;

    // 생성자
    public GPSTracker(Context context){
        myContext = context;
        getLocation();
    }

    // location을 반환
    public Location getLocation() {
        try{
            myLocationManager = (LocationManager)myContext.getSystemService(Context.LOCATION_SERVICE);

            isGPSEnabled = myLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = myLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if(!isNetworkEnabled && !isGPSEnabled) {
                //do Nothing (네트워크와 GPS모두 안되는 상황)
            }
            else{
                this.canGetGPSInfo = true;
                if(isNetworkEnabled) { // 네트워크만 되면 네트워크를 통해서 받아옴
                    myLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_TIME_UPDATES, MIN_DISTANCE_CHANGE_FOR_UPDATES, this);

                    if(myLocation!=null){
                        latitude = myLocation.getLatitude();
                        longitude = myLocation.getLongitude();
                    }
                }

                if(isGPSEnabled){ // GPS만 되면 GPS를 통해서 받아옴
                    if(myLocation == null){
                        // 위치값을 업데이트하여 담는다
                        myLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME_UPDATES, MIN_DISTANCE_CHANGE_FOR_UPDATES, this);

                        if(myLocationManager != null){
                            // 마지막 위치값을 받는다?
                            myLocation = myLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                            if(myLocation != null){
                                //위도 경도 값 가져옴
                                latitude = myLocation.getLatitude();
                                longitude = myLocation.getLongitude();
                            }
                        }
                    }
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return myLocation;
    }
    public void stopUsingGPS(){
        if(myLocation!=null){
            myLocationManager.removeUpdates(GPSTracker.this);
        }
    }
    public double getLatitude() {
        if(myLocation != null) {
            latitude = myLocation.getLatitude();
        }
        return latitude;
    }
    public double getLongitude() {
        if(myLocation != null) {
            longitude = myLocation.getLongitude();
        }
        return longitude;
    }
    public boolean canGetLocation() {
        return this.canGetGPSInfo;
    }

    public void showSettingAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(myContext);
        alertDialog.setTitle("GPS가 설정 중입니다.");
        alertDialog.setMessage("GPS는 활성화되지 않았습니다. 설정메뉴로 이동할까요?");
        alertDialog.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }
    @Override
    public void onLocationChanged(Location location) {
    }
    @Override
    public void onProviderEnabled(String s) {
    }
    @Override
    public void onProviderDisabled(String s) {
    }
    @Override
    public void onStatusChanged(String s, int i, Bundle bundle){
    }

    @Override
    public IBinder onBind(Intent intent){
        return null;
    }

}
