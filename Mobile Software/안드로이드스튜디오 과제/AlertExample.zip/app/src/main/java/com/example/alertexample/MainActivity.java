package com.example.alertexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button myButton;
    String CHANNEL_ID = "default";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myButton = (Button)findViewById(R.id.button);
        myButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                addNotification();
            }
        });
    }

    private void addNotification() {
        // 알림을 만드는 방법 -> Notification Builder
        NotificationCompat.Builder myBuilder = new NotificationCompat.Builder(this, CHANNEL_ID);
        myBuilder.setSmallIcon(R.drawable.ic_launcher_foreground);
        // 알림 속성(제목, 내용) 지정
        myBuilder.setContentTitle("알림이 왔어요");
        myBuilder.setContentText("알림이 잘 구현되었네요.");

        myBuilder.setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent notificationIntent = new Intent(this, MainActivity.class);
        // 해당 인텐트는 새로운 작업(기존 수행 작업 불러오기x)을 시작하는 것으로 지정
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // 알림에 사용되는 액션-> PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        myBuilder.setContentIntent(pendingIntent); // 알림 인스턴스와 결합됨

        //setAutoCancel()은 알림을 탭하면 알림창에서 사라지게 하는 효과임
        myBuilder.setAutoCancel(true);

        // 알림을 보내는 구문을 작성
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
        manager.notify(0, myBuilder.build());
    }

    // 알림에 맞는 채널을 만들어 시스템에 등록시켜야 함
        private void createNotificationChannel() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                CharSequence name = getString(R.string.channel_name);
                String description = getString(R.string.channel_description);
                int importance = NotificationManager.IMPORTANCE_DEFAULT; // 알림의 중요도 지정

                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
                channel.setDescription(description);

                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                notificationManager.createNotificationChannel(channel);
            }

        }

}
