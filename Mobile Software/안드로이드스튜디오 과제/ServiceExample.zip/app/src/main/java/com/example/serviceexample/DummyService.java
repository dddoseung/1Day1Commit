package com.example.serviceexample;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.view.Gravity;
import android.widget.Toast;

public class DummyService extends Service {
    public DummyService() {
    }
    @Override

//    OnBind() 메소드는 서비스 클래스를 inherit 하는 클래스를 구현하게
//    되면 필수적으로 넣어야 하는 메소드
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //toast 객체는 화면에 메시지를 보여주는 작업을 수행하는 객체

        Toast toast = Toast.makeText(this, "Service is started", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
        return START_STICKY; // continue running until it is explicitly stopped.
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast toast = Toast.makeText(this, "Service is destroyed", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }
}