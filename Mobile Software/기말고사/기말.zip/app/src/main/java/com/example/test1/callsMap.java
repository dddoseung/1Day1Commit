package com.example.test1;

public class callsMap {
    private String name;
    private String place_lati;
    private String place_long; // 핸드폰 번호

    public String getName() {
        return name;
    }
    public String getLati() {
        return place_lati;
    }
    public String getLong() {
        return place_long;
    }


    public callsMap(String name, String place_lati,String place_long) {
        this.name=name;
        this.place_lati=place_lati;
        this.place_long = place_long;

    }
}
