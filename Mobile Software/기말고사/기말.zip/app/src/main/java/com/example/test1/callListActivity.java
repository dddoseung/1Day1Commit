package com.example.test1;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class callListActivity extends Activity implements View.OnClickListener {

    private ArrayList<callsItem> data = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /* xml과 연결 */
        setContentView(R.layout.calls_list);

        ListView listView = (ListView) findViewById(R.id.calls_listView);

        /* 서버와 연동했닫면 값을 받아서 띄울 수 있지만,
         * 연동이 되어있지 않으므로
         * 하드코딩으로 값을 집어넣는다.
         * FriendsItem에 정의 한 구조대로 값을 넣을 수 있다.
         */
        data = new ArrayList<>();
        // 1번 아이템
        callsItem friends1 = new callsItem("학사운영실","02-2260-3833");

        //2번 아이템
        callsItem friends2 = new callsItem("정보통신공","02-2260-3833");

        //3번 아이템
        callsItem friends3 = new callsItem("학장실","02-2260-3833");
        //리스트에 추가
        data.add(friends1);
        data.add(friends2);
        data.add(friends3);


        /* 리스트 속의 아이템 연결 */
        callsAdapter adapter = new callsAdapter(this, R.layout.calls_item, data);
        listView.setAdapter(adapter);

        /* 아이템 클릭시 작동 */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:01022603833"));
                startActivity(intent);
            }
        });

    }

    @Override
    public void onClick(View v) {
    }

}
