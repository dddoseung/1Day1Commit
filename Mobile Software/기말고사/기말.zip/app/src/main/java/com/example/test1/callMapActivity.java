package com.example.test1;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class callMapActivity extends Activity implements View.OnClickListener {

    private ArrayList<callsMap> data = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /* xml과 연결 */
        setContentView(R.layout.mapslist);

        ListView listView = (ListView) findViewById(R.id.calls_mapView);

        /* 서버와 연동했닫면 값을 받아서 띄울 수 있지만,
         * 연동이 되어있지 않으므로
         * 하드코딩으로 값을 집어넣는다.
         * FriendsItem에 정의 한 구조대로 값을 넣을 수 있다.
         */
        data = new ArrayList<>();
        // 1번 아이템
        callsMap friends1 = new callsMap("신공학관","37.558058787929134","126.99840306484138");

        //2번 아이템
        callsMap friends2 = new callsMap("학사운영실","37.5589262868377","126.99889548582202");

        //3번 아이템
        callsMap friends3 = new callsMap("기숙사","37.558402166228966","126.99814771755447");
        //리스트에 추가
        data.add(friends1);
        data.add(friends2);
        data.add(friends3);


        /* 리스트 속의 아이템 연결 */
        mapsAdapter adapter = new mapsAdapter(this, R.layout.calls_map, data);
        listView.setAdapter(adapter);

        /* 아이템 클릭시 작동 */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), mapActivity.class);
                Bundle data1 = new Bundle();
                /* putExtra의 첫 값은 식별 태그, 뒤에는 다음 화면에 넘길 값 */
                intent.putExtra("place_lati",data.get(position).getLati());
                intent.putExtra("place_long",data.get(position).getLong());
                startActivity(intent);

            }
        });

    }

    @Override
    public void onClick(View v) {
    }

}
