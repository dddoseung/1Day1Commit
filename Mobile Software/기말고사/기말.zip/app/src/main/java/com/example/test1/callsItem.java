package com.example.test1;

public class callsItem {

    private String name;
    private String phone; // 핸드폰 번호


    public String getName() {
        return name;
    }
    public String getPhone() {
        return phone;
    }


    public callsItem(String name,String phone) {
        this.name=name;
        this.phone = phone;

    }
}
