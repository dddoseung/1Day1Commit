package com.example.traveldiary;

// 데이터 관리 역할을 하는 어댑터 클래스를 만들 것임
// 그 안에 각 아이템으로 표시할 뷰를 리턴하는 getView() 메소드를 정의.

import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DiaryListActivity extends AppCompatActivity {
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diarylist_item_main);

        ListView listView = findViewById(R.id.listView);
        SingleAdapter adapter = new SingleAdapter();
        adapter.addItem(new diarylist_item("제주도"));
        adapter.addItem(new diarylist_item("부산"));
        ///

        listView.setAdapter(adapter);
    }

    class SingleAdapter extends BaseAdapter{

    }
}