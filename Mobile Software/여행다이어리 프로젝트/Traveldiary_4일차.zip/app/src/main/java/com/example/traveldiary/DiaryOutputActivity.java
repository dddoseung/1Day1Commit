package com.example.traveldiary;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class DiaryOutputActivity extends AppCompatActivity {
    ImageView imageView;

    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diaryoutput_main);

        System.out.println("Android App : On Create");
        String[] columns = new String[]{"place_name","place_descrip","place_lati","place_long"};
//        String[] columns = new String[]{"place_name","place_descrip","place_img"};
        Cursor c = getContentResolver().query(MyContentProvider.CONTENT_URI,
                        columns, null,
                        null, null, null);

        // DiartListActivity에서 넘겨준 값을 받아옴
        Intent intent = getIntent();
        EditText editMultipleText = findViewById(R.id.editText4);
        EditText editMultipleText2 = findViewById(R.id.editText5);
//        ImageView editImage=findViewById(R.id.getImage);
        String str=intent.getStringExtra("place_name"); // 값 받기

        // 알맞게 내용값 띄워줌
        if(c!=null) {
            while (c.moveToNext()) {
                if (str.equals(c.getString(0))) {
                    editMultipleText.setText(str);
                    editMultipleText2.setText(c.getString(1));
//                    setImage(Uri.parse(c.getString(2)));
                    break;
                }
            }
        }

    }
    private void setImage(Uri uri) {
        try{
            InputStream in = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            imageView=findViewById(R.id.getImage);
            imageView.setImageBitmap(bitmap);
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }

}
