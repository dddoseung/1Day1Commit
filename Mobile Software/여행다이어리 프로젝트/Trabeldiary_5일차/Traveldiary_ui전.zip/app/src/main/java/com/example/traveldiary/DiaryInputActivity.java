package com.example.traveldiary;
//여행 입력의 mainActivity

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileNotFoundException;

import java.io.InputStream;



public class DiaryInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) { // 여행지 정보 + 사진
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diaryinput_main);
        System.out.println("Android App : On Create");
    }

        static final int REQUEST_CODE = 1;
        ImageView _imageView;
        Uri uri;

    public void onClickButton1(View view){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, REQUEST_CODE);
    }

    /***********DB에 저장함************/
    public void addPlace(View view){

        ContentValues addValues = new ContentValues();
        addValues.put(MyContentProvider.DESCRIP,
                ((EditText)findViewById(R.id.editText2)).getText().toString()); // 여행지 설명 추가
        addValues.put(MyContentProvider.NAME,
                ((EditText)findViewById(R.id.editText3)).getText().toString()); // 여행장소 이름 추가
        addValues.put(MyContentProvider.IMG,
                uri.toString()); // 여행장소 사진 추가
        addValues.put(MyContentProvider.LATI,
                ((EditText)findViewById(R.id.editText7)).getText().toString()); // 여행지 위도 추가
        addValues.put(MyContentProvider.LONG,
                ((EditText)findViewById(R.id.editText6)).getText().toString()); // 여행지 경도 추가

        getContentResolver().insert(MyContentProvider.CONTENT_URI, addValues);
        Toast.makeText(getBaseContext(), "Record Added.", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            uri = data.getData();
            setImage(uri);
        }
    }

        private void setImage(Uri uri) {
            try{
                InputStream in = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                _imageView=findViewById(R.id.imageView);
                _imageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }
}
