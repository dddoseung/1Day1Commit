package com.example.traveldiary;

// PlaceDBManager 클래스와 DiaryInputActivity를 연결하는 역할

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;


public class MyContentProvider extends ContentProvider {

    static final String PROVIDER_NAME = "com.example.traveldiary.MyContentProvider";
    static final String URL = "content://" + PROVIDER_NAME + "/places";
    static final Uri CONTENT_URI = Uri.parse(URL);
    static final String _ID = "_id";
    static final String NAME = "place_name";
    static final String DESCRIP = "place_descrip";
    static final String IMG= "place_img"; //사진
    static final String LATI="place_lati"; //위도
    static final String LONG="place_long"; //경도
    //"(PlaceDBManager) DB 컬럼명"과 연결
    //전부 다 String!

    public PlaceDBManager dbManager;

    public MyContentProvider() {

    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs){
        return dbManager.delete(selection, selectionArgs);
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values){
        long rowid= dbManager.insert(values);
        return null;
    }

    @Override
    public boolean onCreate(){
        dbManager = PlaceDBManager.getInstance(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection,
                        String selection, String[] selectionArgs, String sortOrder) {
        return dbManager.query(projection, selection, selectionArgs, null, null, sortOrder);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Not yet implemented");
    }


}
