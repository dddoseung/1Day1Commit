package com.example.traveldiary;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends AppCompatActivity

    implements OnMapReadyCallback {
        private GoogleMap googleMap;
        double llati;
        double llong;

    @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);

            setContentView(R.layout.map_main);

            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.googleMap);
            mapFragment.getMapAsync(this);

            //위도,경도값 받기
            Intent intent = getIntent();
            llati=intent.getExtras().getDouble("place_lati"); // double형 값 받기
            llong=intent.getExtras().getDouble("place_long"); // double형 값 받기


        }

        @Override
         public void onMapReady(final GoogleMap googleMap){
            this.googleMap = googleMap;

            //마커를 해당 위도 경도로 위치시키고 카메라도 이동시킴
            LatLng currentLocation = new LatLng(llati, llong);

            //마커에 대한 옵션 설정
            MarkerOptions markerOptions=new MarkerOptions();
            markerOptions.position(currentLocation);
            markerOptions.title("해당 위치입니다.");
            markerOptions.snippet("여행지 위치");
            //줌기능
            googleMap.addMarker(markerOptions);
            //현재 위치로 이동
            googleMap.getUiSettings().setZoomGesturesEnabled(true);

            googleMap.moveCamera(CameraUpdateFactory.newLatLng(currentLocation));
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(15));

        }
    }

