package com.example.traveldiary;
//여행 입력의 mainActivity

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOError;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DiaryInputActivity extends AppCompatActivity {

    private static final int PICK_FROM_ALBUM = 1;
    private static final int PICK_FROM_CAMERA=2;
    private File tempFile;
    private Bitmap originalBm; // 비트맵 형태의 이미지

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) { // 여행지 정보 + 사진
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diaryinput_main);
        System.out.println("Android App : On Create");

        findViewById(R.id.btnGallery).setOnClickListener(new View.OnClickListener(){ // 갤러리연결
            @Override
            public void onClick(View view) {
                goToAlbum();
            }
        });

        findViewById(R.id.btnCamera).setOnClickListener(new View.OnClickListener(){ // 카메라연결
            @Override
            public void onClick(View view){
                takePhoto();
            }
        });
    }

    /*이미지 bitmap->byte[]로 전환*/
    public byte[] getByteArrayFromDrawable(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] data=stream.toByteArray();

        return data;
    }

    byte[] byte_img=getByteArrayFromDrawable(originalBm);

    /***********DB에 저장함************/
    public void addPlace(View view){
        ContentValues addValues = new ContentValues();
        addValues.put(MyContentProvider.DESCRIP,
                ((EditText)findViewById(R.id.editText2)).getText().toString()); // 여행지 설명 추가
        addValues.put(MyContentProvider.NAME,
                ((EditText)findViewById(R.id.editText3)).getText().toString()); // 여행장소 이름 추가
        addValues.put(MyContentProvider.IMG, byte_img); // 여행장소 사진 추가
        addValues.put(MyContentProvider.LATI,
                ((EditText)findViewById(R.id.editText7)).getText().toString()); // 여행지 위도 추가
        addValues.put(MyContentProvider.LONG,
                ((EditText)findViewById(R.id.editText6)).getText().toString()); // 여행지 경도 추가

        getContentResolver().insert(MyContentProvider.CONTENT_URI, addValues);
        Toast.makeText(getBaseContext(), "Record Added.", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != Activity.RESULT_OK){
            Toast.makeText(this, "취소되었습니다.",Toast.LENGTH_SHORT).show();

            if(tempFile !=null){
                if(tempFile.exists()){
                    if(tempFile.delete()){
                        tempFile = null;
                    }
                }
            }
            return;
        }

        if(requestCode == PICK_FROM_ALBUM){
            Uri photouri = data.getData(); // 갤러리에서 선택한 이미지의 Uri를 받아옴
            Cursor cursor=null;

            try{
                /*
                 *  Uri 스키마를
                 *  content:/// 에서 file:/// 로  변경한다.->절대경로를 받아온다.
                 */
                String[] proj = {MediaStore.Audio.Media.DATA};

                assert photouri != null;
                cursor = getContentResolver().query(photouri,proj,null,null,null);

                assert cursor != null;
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

                cursor.moveToFirst();

                tempFile = new File(cursor.getString(column_index));
            }finally{
                if(cursor != null){
                    cursor.close();
                }
            }
            setImage();
        }
        else if (requestCode == PICK_FROM_CAMERA) {
            setImage();
        }
    }

    // 앨범에서 이미지 가져오기
    public void goToAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
    }

    /**
     *  카메라에서 이미지 가져오기
     */
    private void takePhoto() {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        try {
            tempFile = createImageFile();
        } catch (IOException e) {
            Toast.makeText(this, "이미지 처리 오류! 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
            finish();
            e.printStackTrace();
        }
        if (tempFile != null) {

            Uri photoUri = Uri.fromFile(tempFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(intent, PICK_FROM_CAMERA);
        }
    }

    //폴더 및 파일 만들기
    private File createImageFile() throws IOException {

        // 이미지 파일 이름 ( diary_{시간}_ )
        String timeStamp = new SimpleDateFormat("HHmmss").format(new Date());
        String imageFileName = "diary_" + timeStamp + "_";

        // 이미지가 저장될 폴더 이름 ( diary )
        File storageDir = new File(Environment.getExternalStorageDirectory() + "/diary/");
        if (!storageDir.exists()) storageDir.mkdirs();

        // 빈 파일 생성
        File image = File.createTempFile(imageFileName, ".png", storageDir);

        return image;
    }

    //ImageView에 띄어줌
    private void setImage() {

        ImageView imageView = findViewById(R.id.imageView);
        BitmapFactory.Options options = new BitmapFactory.Options();
        originalBm = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), options);
        // 전역변수 tempFile의 경로를 불러와 bitmap파일로 변형한 후

        imageView.setImageBitmap(originalBm); // imageView에 넣어줌

        tempFile=null;
    }
}
