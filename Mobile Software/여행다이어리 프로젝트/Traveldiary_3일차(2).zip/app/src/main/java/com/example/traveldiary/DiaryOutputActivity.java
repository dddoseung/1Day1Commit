package com.example.traveldiary;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;

public class DiaryOutputActivity extends AppCompatActivity {
    private int index;

    public void getPlace(View view) {
        String[] columns = new String[]{"place_name","place_descrip","place_img","place_lati","place_long"};
        Cursor c = getContentResolver().query(MyContentProvider.CONTENT_URI,
                        columns, null,null, null, null);
        index= (Integer.parseInt(getIntent().getStringExtra("place_name")))*5; // 값 받아옴

            EditText nameText = findViewById(R.id.editText4);
            EditText descripText=findViewById(R.id.editText5);
            ImageView getView=findViewById(R.id.getImage);

            nameText.setText("");
            descripText.setText("");


                String p_name = c.getString(index);
                String p_descrip = c.getString(index+1);
                byte[] tmp_image = c.getBlob(index+2);
                Bitmap p_image = getImage(tmp_image);

                nameText.append(p_name);
                descripText.append(p_descrip);
                getView.setImageBitmap(p_image); // imageView에 넣어줌


            c.close();

    }

    /*이미지 byte[] -> bitmap으로 변환 */
    public Bitmap getImage(byte[] b){
        Bitmap bitmap = BitmapFactory.decodeByteArray(b,0,b.length);
        return bitmap;
    }
}
