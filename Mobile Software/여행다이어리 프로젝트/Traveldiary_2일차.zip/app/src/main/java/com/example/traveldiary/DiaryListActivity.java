package com.example.traveldiary;

// 데이터 관리 역할을 하는 어댑터 클래스를 만들 것임
// 그 안에 각 아이템으로 표시할 뷰를 리턴하는 getView() 메소드를 정의.

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DiaryListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diarylist_item_main);

        ListView listView = findViewById(R.id.listView);
        SingleAdapter adapter = new SingleAdapter();
        adapter.addItem(new diarylist_item("제주도"));
        adapter.addItem(new diarylist_item("부산"));
        ///

        listView.setAdapter(adapter);
    }

    class SingleAdapter extends BaseAdapter {
        ArrayList<diarylist_item> items = new ArrayList<diarylist_item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(diarylist_item item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }


        @Override
        public long getItemId(int position) {
            return position;
        }

        //어댑터가 데이터를 관리하고 뷰도 만든다
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            DiaryList_ItemView diaryView = null;
            //코드를 재사용할 수 있도록
            if (convertView == null) {
                diaryView = new DiaryList_ItemView(getApplicationContext());
            } else {
                diaryView = (DiaryList_ItemView) convertView;
            }
            diarylist_item item = items.get(position);
            diaryView.setName(item.getName());
            return diaryView;
        }

    }
}