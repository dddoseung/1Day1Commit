package com.example.traveldiary;

 // diarylist_item에서 정의한 아이템을 다루는(인플레이션하는) 자바 파일

// 아이템 레이아웃(singer_diarylist)을 인플레이션하여 참조할 수 있게 한다

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class DiaryList_ItemView extends LinearLayout {

    //어디서든 사용할 수 있게 하려면
    TextView textView;

    public DiaryList_ItemView(Context context){
        super(context);
        init(context); //인플레이션해서 붙여주는 역
    }

    public DiaryList_ItemView(Context context, @Nullable AttributeSet attrs){
        super(context, attrs);
    }

    //지금 만든 객체(xml 레이아웃)를 인플레이션화(메모리 객체화)해서 붙여줌
    //LayoutInflater를 써서 시스템 서비스를 참조할 수 있음
    //단말이 켜졌을 때 기본적으로 백그라운드에서 실행시키는 것을 시스템 서비스라고 함
    private void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.singer_diarylist,this,true);

        textView = findViewById(R.id.textView9); // 여행지이름: 제주도, 충청도....
    }

    public void setName(String name){
        textView.setText(name);
    }

}
