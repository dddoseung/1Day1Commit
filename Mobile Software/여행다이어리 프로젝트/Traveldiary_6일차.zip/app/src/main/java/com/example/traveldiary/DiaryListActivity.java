package com.example.traveldiary;

// 데이터 관리 역할을 하는 어댑터 클래스를 만들 것임
// 그 안에 각 아이템으로 표시할 뷰를 리턴하는 getView() 메소드를 정의.

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DiaryListActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<diarylist_item> items=null;
    //여행지 이름을 담을 배열리스트

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diarylist_item_main);

        final ListView listView = findViewById(R.id.listView);
        final SingleAdapter adapter = new SingleAdapter();
        items = new ArrayList<>();

        /* DB에 저장된 값을 불러온다*/
        String[] columns = new String[]{"place_name"}; // SQLite DB에 생성된 테이블의 place_name 열 값들을 배열에 저장
        Cursor c = getContentResolver().query(MyContentProvider.CONTENT_URI, columns, null,
                null, null, null);

        /*그 값들을 adapter에 추가시켜준다*/
        if (c != null) {
            while (c.moveToNext()) {
                String name = c.getString(0); // name={"제주도", "...", ... } 반복하여
                adapter.addItem(new diarylist_item(name)); // adapter에 추가
            }
            c.close();
        }

        /*리스트를 연결해준다*/
        listView.setAdapter(adapter); // 리스트 연결


        /*리스트 클릭 시 db에 저장했던 일기 입력 불러오기*/
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), DiaryOutputActivity.class);
                intent.putExtra("place_name", items.get(position).getName());
                /* putExtra의 첫 값은 식별 태그, 뒤에는 다음 화면에 넘길 값 */
                startActivity(intent);
            }
        });

    }

    @Override
    public void onClick(View v) {
    }


    public class SingleAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(diarylist_item item){
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }


        @Override
        public long getItemId(int position) {
            return position;
        }

        //어댑터가 데이터를 관리하고 뷰도 만든다
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            DiaryList_ItemView diaryView = null;
            //코드를 재사용할 수 있도록
            if (convertView == null) {
                diaryView = new DiaryList_ItemView(getApplicationContext());
            } else {
                diaryView = (DiaryList_ItemView) convertView;
            }
            diarylist_item item = items.get(position);
            diaryView.setName(item.getName());
            return diaryView;
        }

    }
}