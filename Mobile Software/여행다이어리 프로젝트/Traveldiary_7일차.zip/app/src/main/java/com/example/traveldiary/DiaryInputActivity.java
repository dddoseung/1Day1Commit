package com.example.traveldiary;
//여행 입력의 mainActivity

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileNotFoundException;

import java.io.InputStream;



public class DiaryInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) { // 여행지 정보 + 사진
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diaryinput_main);
        System.out.println("Android App : On Create");
    }

        static final int REQUEST_CODE = 1;
        ImageView imageView;
        Uri uri;

    public void onClickButton1(View view){ // 갤러리 버튼 onCLick()
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            uri = data.getData(); // 이미지의 uri를 가져옴
        }
        setImage(uri);
    }

    /*********** DB에 저장함 ************/
    public void addPlace(View view){

        ContentValues addValues = new ContentValues();
        addValues.put(MyContentProvider.DESCRIP,
                ((EditText)findViewById(R.id.editText5)).getText().toString()); // plain text에 입력되는 text를 받아와서 db에 설명값 저장
        addValues.put(MyContentProvider.NAME,
                ((EditText)findViewById(R.id.editText4)).getText().toString()); // 이름 저장
        addValues.put(MyContentProvider.IMG,
                ((EditText)findViewById(R.id.iv_uri)).getText().toString()); // 사진 저장

        addValues.put(MyContentProvider.LATI,
                ((EditText)findViewById(R.id.editText7)).getText().toString()); // 위도 저장
        addValues.put(MyContentProvider.LONG,
                ((EditText)findViewById(R.id.editText6)).getText().toString()); // 경도 저장

        getContentResolver().insert(MyContentProvider.CONTENT_URI, addValues);
        Toast.makeText(getBaseContext(), "Record Added.", Toast.LENGTH_LONG).show();
    }



        private void setImage(Uri uri) {
            try{
                InputStream in = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(in);

                EditText ivuri = findViewById(R.id.iv_uri);
                ivuri.setText(uri.toString());

                imageView=findViewById(R.id.imageView);
                imageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }
}
