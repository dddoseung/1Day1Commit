package com.example.traveldiary;

// 아이템 구성(변수) 정의

public class diarylist_item {
    String name;

    public diarylist_item(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
}
