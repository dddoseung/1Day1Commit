package com.example.traveldiary;
//여행 입력의 mainActivity
import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DiaryInputActivity extends AppCompatActivity {
    String msg="----------: ";

    @Override
    protected void onCreate(Bundle savedInstanceState) { // 여행지
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diaryinput_main);
        System.out.println("Android App : On Create");
    }

    public void addStudent(View view){ // "입력 완료" 버튼과 연결
        ContentValues addValues = new ContentValues();
        addValues.put(MyContentProvider.DESCRIP,
                ((EditText)findViewById(R.id.editText2)).getText().toString()); // 여행지 설명
        addValues.put(MyContentProvider.NAME,
                ((EditText)findViewById(R.id.editText3)).getText().toString()); // 여행장소 이름


        getContentResolver().insert(MyContentProvider.CONTENT_URI, addValues);
        Toast.makeText(getBaseContext(), "Record Added.", Toast.LENGTH_LONG).show();
    }

//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) { // 사진
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.active_get_image);
//        tedPermission();
//    }


}
