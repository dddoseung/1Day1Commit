const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({
  extended: true
}));

app.set('view engine', 'ejs'); // 꼭 view engine

var item=[];

app.get("/", function(req, res) {
  var today = new Date();
  var currentToday = today.getDay(); // 일요일: 0 월요일: 1 화요일: 2 ...

  //var arr=new Array('Sunday','Monday','Thuesday','Wednesday','Thursday','Friday','Saturday');

  // var day=arr[currentToday];
  // if(currentToday === 6 || currentToday === 0){ //토요일 or 일요일
  //   day="weekend";
  // }
  // else{
  //   day="weekday";
  // }

  var options = {
    weekday: 'long',
    //year: 'numeric',
    month: 'long',
    day: 'numeric'
  };

  var day = today.toLocaleDateString("en-US", options);

  // "list" is list.ejs (ejs rendering)
  res.render("list", {kindOfDay: day, newListItem: item});
});

app.post("/", function(request,response) {
  item = request.body.newItem;
  // res.render("list", {newListItem: item}); render를 두 번 하면 오류 난다
  item.push(item);
  res.redirect("/"); // app.get("/")으로 돌아간다
});

app.listen(3000, function() {
  console.log("server port 3000");
});
