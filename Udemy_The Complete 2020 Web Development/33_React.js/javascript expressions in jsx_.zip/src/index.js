import React from "react";
import ReactDOM from "react-dom";

const lname = "Seunghyun";
const fname = "Do";

ReactDOM.render(
  <div>
    <h1>Hello {lname + " " + fname}! </h1>
    <h1>
      Hello {lname} {fname}!
    </h1>
    <h1>Hello {`${lname} ${fname}`}! </h1>

    <p>Your lucky number is {Math.floor(Math.random() * 10)}</p>
    {/* any javascript expression in { } */}
  </div>,
  document.getElementById("root")
);
