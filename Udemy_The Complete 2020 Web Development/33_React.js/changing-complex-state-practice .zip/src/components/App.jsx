import React, { useState } from "react";

function App() {
  const [contact, setContact] = useState({
    fName: "",
    lName: "",
    email: ""
  });

  function handleContact(event) {
    const { name, value } = event.target;

    setContact((x) => {
      // 이 안에 event.target~ 있으면 안됨

      if (name === "fName") {
        return {
          fName: value,
          lName: x.lName,
          email: x.email
        };
      } else if (name === "lName") {
        return {
          fName: x.fName,
          lName: value,
          email: x.email
        };
      } else if (name === "email") {
        return {
          fName: x.fName,
          lName: x.lName,
          email: value
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {contact.fName} {contact.lName}
      </h1>
      <p>{contact.email}</p>
      <form>
        <input
          onChange={handleContact}
          name="fName"
          placeholder="First Name"
          value={contact.fName}
        />
        <input
          onChange={handleContact}
          name="lName"
          placeholder="Last Name"
          value={contact.lName}
        />
        <input
          onChange={handleContact}
          name="email"
          placeholder="Email"
          value={contact.email}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;
