// React의 가장 큰 특징은
// '컴포넌트화'
// 간결하고 보기 쉬움

import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

//[방법1]
// function Title(){
//   return <h1>My Favourite Foods </h1>;
// }

//[방법2]
// Title.jsx 파일 만듦 & import
// import Title from "./Title";

ReactDOM.render(
  <div>
    {/* <Title />
    <List /> */}
    <App />
  </div>,
  document.getElementById("root")
);
