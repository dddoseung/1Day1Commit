import React from "react";

function InputArea(props) {
  const handleChange = props.handleChange;
  const inputText = props.inputText;
  const addItem = props.addItem;
  return (
    <div className="form">
      <input onChange={handleChange} type="text" value={inputText} />
      <button onClick={addItem}>
        <span>Add</span>
      </button>
    </div>
  );
}

export default InputArea;
