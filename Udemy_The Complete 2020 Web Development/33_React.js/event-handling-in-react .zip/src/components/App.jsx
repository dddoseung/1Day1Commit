import React, { useState } from "react";

function App() {
  const [current, currentOver] = useState(false);
  function MouseOver() {
    currentOver(true);
  }
  function MouseOut() {
    currentOver(false);
  }
  function styleCondition() {
    return { backgroundColor: current === false ? "white" : "black" };
  }
  return (
    <div className="container">
      <h1>Hello</h1>
      <input type="text" placeholder="What's your name?" />
      <button
        style={styleCondition()}
        onMouseOver={MouseOver}
        onMouseOut={MouseOut}
      >
        Submit
      </button>
    </div>
  );
}

export default App;
