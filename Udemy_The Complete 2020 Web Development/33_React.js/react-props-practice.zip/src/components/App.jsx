import React from "react";
import Card from "./Card";
import contacts from "../contacts";

const Beyonce = contacts[0];
const Jack = contacts[1];
const Chuck = contacts[2];

function App() {
  return (
    <div>
      <h1 className="heading">My Contacts</h1>
      <Card
        name={Beyonce.name}
        imgURL={Beyonce.imgURL}
        phone={Beyonce.phone}
        email={Beyonce.email}
      />

      <Card
        name={Jack.name}
        imgURL={Jack.imgURL}
        phone={Jack.phone}
        email={Jack.email}
      />

      <Card
        name={Chuck.name}
        imgURL={Chuck.imgURL}
        phone={Chuck.phone}
        email={Chuck.email}
      />
    </div>
  );
}

export default App;
