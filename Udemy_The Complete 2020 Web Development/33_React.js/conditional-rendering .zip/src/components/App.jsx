import React from "react";
import Login from "./Login";

var isLoggedIn = true;

function App() {
  return (
    <div className="container">
      {/* {isLoggedIn===false ? <Login /> : <h1>hello</h1>} */}
      {/* === */}
      {isLoggedIn === false && <Login />}
      {isLoggedIn === true && <h1>Hello</h1>}
    </div>
  );
}

export default App;
