import React, { useState } from "react";

// useState = [initialState, function]

function App() {
  let now = new Date().toLocaleTimeString("it-IT");
  const [time, getTime] = useState(now);

  {
    setInterval(updateTime, 1000);
  }

  function updateTime() {
    now = new Date().toLocaleTimeString("it-IT");
    return getTime(now);
  }
  return (
    <div className="container">
      <h1>{time}</h1>
      <button onClick={updateTime}>Get Time</button>
    </div>
  );
}

export default App;
