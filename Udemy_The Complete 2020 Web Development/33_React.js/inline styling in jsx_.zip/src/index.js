import React from "react";
import ReactDOM from "react-dom";

// inline Styling css
// 장점: 속성을 적용할 때마다 바뀐다.

const change = {
  // key: value
  fontSize: "20px",
  color: "purple",
  border: "1px"
};

change.color = "blue";
change.fontSize = "100px";

ReactDOM.render(
  <div>
    <h1 style={{ color: "red" }}> Hello World! </h1>
    <h2 style={change}> Hi </h2>
  </div>,
  document.getElementById("root")
);
