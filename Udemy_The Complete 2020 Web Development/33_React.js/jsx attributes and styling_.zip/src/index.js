import React from "react";
import ReactDOM from "react-dom";

const img1 = "https://picsum.photos/200";
// https://picsum.photos/

ReactDOM.render(
  <div>
    <h1 className="heading" spellCheck="true" contentEditable="true">
      My Favourite Fooods
    </h1>
    <ul>
      <li>Bacon</li>
      <li>Jamon</li>
      <li>Noodles</li>
    </ul>

    <div>
      <img alt="random" className="image" src={img1 + "?grayscale"} />
      <img
        alt="cafe"
        className="image"
        src="https://picsum.photos/id/1060/536/354"
      />
    </div>
  </div>,
  document.getElementById("root")
);
