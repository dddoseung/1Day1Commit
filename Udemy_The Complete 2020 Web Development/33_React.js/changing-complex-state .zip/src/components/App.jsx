import React, { useState } from "react";

function App() {
  const [fullName, handleFull] = useState({ fName: "" }, { lName: "" });

  function handleFunc(event) {
    const { name, value } = event.target;

    handleFull(function preValue(x) {
      if (name === "fName") {
        return {
          fName: value,
          lName: x.lName
        };
      } else if (name === "lName") {
        return {
          fName: x.fName,
          lName: value
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {fullName.fName} {fullName.lName}
      </h1>
      <form>
        <input
          onChange={handleFunc}
          name="fName"
          placeholder="First Name"
          value={fullName.fName}
        />
        <input
          onChange={handleFunc}
          name="lName"
          placeholder="Last Name"
          value={fullName.lName}
        />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
