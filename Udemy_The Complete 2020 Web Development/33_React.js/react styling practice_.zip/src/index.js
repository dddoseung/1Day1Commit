//Create a React app from scratch.
//Show a single h1 that says "Good morning" if between midnight and 12PM.
//or "Good Afternoon" if between 12PM and 6PM.
//or "Good evening" if between 6PM and midnight.
//Apply the "heading" style in the styles.css
//Dynamically change the color of the h1 using inline css styles.
//Morning = red, Afternoon = green, Night = blue.
import React from "react";
import ReactDOM from "react-dom";

const time = new Date().getHours();
let mention = "";
const style = {
  color: "red"
};

// 흠 12<=time<=18 이런 식으로 하니까 안됨
// JSX는 time<=18 이렇게만 할 수 있나봄..?
if (time <= 18) {
  mention = "good afternoon";
  style.color = "green";
} else if (time <= 24) {
  mention = "good Evening";
  style.color = "blue";
} else {
  mention = "good morning";
}
console.log(mention);
ReactDOM.render(
  <div>
    <h1 style={style} className="heading">
      {mention}
    </h1>
  </div>,
  document.getElementById("root")
);
