import React, { useState } from "react";
import Note from "./Note";

function CreateArea(event) {
  const [inputText, setInputText] = useState({ title: "", content: "" });
  const [items, setItems] = useState([]);

  function handleInputText(event) {
    const { name, value } = event.target;

    setInputText((prevNote) => {
      return {
        ...prevNote,
        [name]: value // 배열이어야 함
      };
    });
  }

  function addItem(event) {
    setItems((prevItems) => {
      return [
        ...prevItems,
        // inputText
        { title: inputText.title, content: inputText.content }
      ];
    });
    setInputText({ title: "", content: "" });

    event.preventDefault();
  }

  function deleteItem(id) {
    setItems((prevItems) => {
      return prevItems.filter((item, index) => {
        return id !== index;
      });
    });
  }

  return (
    <div>
      <form>
        <input
          name="title"
          onChange={handleInputText}
          placeholder="Title"
          value={inputText.title}
        />
        <textarea
          name="content"
          onChange={handleInputText}
          placeholder="Take a note..."
          value={inputText.content}
          rows="3"
        />
        <button onClick={addItem}>Add</button>
      </form>
      {items.map((todoItem, index) => (
        <Note
          key={index}
          id={index}
          title={todoItem.title}
          content={todoItem.content}
          onChecked={deleteItem}
        />
      ))}
      {/* <Note key={1} title="Note title" content="Note content" /> */}
    </div>
  );
}

export default CreateArea;
