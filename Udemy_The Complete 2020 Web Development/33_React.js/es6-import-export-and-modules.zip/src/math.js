const pi = 3.141592;

function doublePi() {
  return pi * 2;
}

function triplePi() {
  return pi * 3;
}

export default pi;
export { doublePi, triplePi }; // 두 모듈은 이런 식으로
