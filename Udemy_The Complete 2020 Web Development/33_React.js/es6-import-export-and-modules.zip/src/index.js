import React from "react";
import ReactDOM from "react-dom";
// import pi from "./math";
// import { triplePi, doublePi } from "./math";

import * as pi from "./math";

ReactDOM.render(
  <div>
    <ul>
      {/* math.js ( JSX파일이 아니므로 < >(X) ) */}
      {/* <li>{pi}</li>
      <li>{doublePi()}</li>
      <li>{triplePi()}</li> */}

      <li>{pi.default}</li>
      <li>{pi.doublePi()}</li>
      <li>{pi.triplePi()}</li>
    </ul>
  </div>,
  document.getElementById("root")
);
