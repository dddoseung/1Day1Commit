import emojipedia from "./emojipedia";

var numbers = [3, 56, 2, 48, 5];

//1) Map -Create a new array by doing something with each item in an array.
function Double(x) {
  return x * 2;
}
var mapNumbers = numbers.map(Double);
// ==
var mapNumbers = numbers.map(function (x) {
  return x * 2;
});
console.log(mapNumbers);

//2) Filter - Create a new array by keeping the items that return true.
var filterNumbers = numbers.filter(function (x) {
  return x > 10;
});
console.log(filterNumbers);

//3) Reduce - Accumulate a value by doing something to each item in an array.
// sum이랑 같음
var reduceNumbers = numbers.reduce(function (sum, x) {
  // sum은 총합을 담는 변수, x는 현재값
  return sum + x;
});
console.log(reduceNumbers);

//4) Find - find the first item that matches from an array.
// Filter와 비슷하나, 찾으면 해당값 한 개만 리턴됨
var findNumbers = numbers.find(function (x) {
  return x > 10;
});
console.log(findNumbers);

//5) FindIndex - find the index of the first item that matches.
// Find값의 index가 리턴됨
var findindexNumber = numbers.findIndex(function (x) {
  return x > 10;
});
console.log(findindexNumber);

//emojipedia 배열값들의 meaning만 50자 제한으로 나타내기
const mean = emojipedia.map(function (x) {
  return x.meaning.substring(0, 50); // 50자 제한된 상태로 저장됨
});
console.log(mean);
