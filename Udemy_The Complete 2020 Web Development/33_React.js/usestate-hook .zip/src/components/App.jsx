import React, { useState } from "react";

function App() {
  const [count, setCount] = useState(1); // useState(initialState)

  // useState = [initialState, function]
  // this function is to update initialState

  function Increase() {
    return setCount(count + 1);
  }
  function Decrease() {
    return setCount(count - 1);
  }

  return (
    <div className="container">
      <h1>{count}</h1>
      <button onClick={Increase}>+</button>
      <button onClick={Decrease}>-</button>
    </div>
  );
}

export default App;
