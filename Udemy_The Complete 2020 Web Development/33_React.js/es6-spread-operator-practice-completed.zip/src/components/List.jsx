import React from "react";

function List(prop) {
  const arr = prop.new;

  return (
    <div>
      <ul>
        {arr.map(function (x) {
          return <li>{x}</li>;
        })}
        {/* <li>{arr}</li> */}
      </ul>
    </div>
  );
}

export default List;
