import React, { useState } from "react";

function App() {
  const [current, Edit] = useState("");
  const [tf, tfFunc] = useState();

  function EditWord(event) {
    Edit(event.target.value); //event가 일어나는 것에 value값
  }
  function btnClick(event) {
    tfFunc(current);

    event.preventDefault(); // form의 새로고침되는 default action을 막음
  }

  return (
    <div className="container">
      <form onSubmit={btnClick}>
        {/* button onClick={btnClick}을 대신하는 것 */}
        <h1>Hello {tf}</h1>
        <input
          onChange={EditWord}
          type="text"
          placeholder="What's your name?"
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;
