//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb://localhost:27017/todolistDB",{ useNewUrlParser:
true },{ useUnifiedTopology: true });


const itemsSchema = new mongoose.Schema({
  name: String
});

const Item = mongoose.model("Item",itemsSchema);

const item1 = new Item({
  name: "Welcome to your todoList!"
})

const item2 = new Item({
  name: "Hit the + button to add a new item."
})

const item3 = new Item({
  name: "<-- Hit this to delete an item."
})

const defaultItems = [item1, item2, item3];

const listSchema = {
  name: String,
  items: [itemsSchema]
};

const List = mongoose.model("List",listSchema);


app.get("/", function(req, res) {

// !만약 각각의 데이터의 name이나 특정 열값만 불러오고 싶으면 js가 아닌
//  ejs에서 건드려야 함 (방법2 처럼 하면 오류!)

  Item.find({},function(err,items){ // {}는 배열이 출력된다
    if(items.length===0){
      Item.insertMany(defaultItems, function(err){
        if(err){
          console.log(err);
        }else{
          console.log("success insert all.");
        }
      });
    }else{
      res.render("list",{listTitle: "Today", newListItems: items});
    }
      //mongoose.connection.close(); -> redirect 안먹음
    })
  });

//[방법2 (X)]

  // Item.find(function(err,items){
  //   items.forEach(function(element){
  //     res.render("list",{listTitle: "today", newListItems: element.name});
  //   });
  // });


app.post("/", function(req, res){

  const itemName = req.body.newItem; // req.body.newItem의 value값 (즉, 사용자 입력 값)

  const item4 = new Item({
    name: itemName
  });

  item4.save();

  if(req.body.list==="Today"){ // req.body.list의 value값
    res.redirect("/");
  }else{
    let tmp=new List({
      name: req.body.list,
      items: item4
    });
    tmp.save();

    res.redirect("/"+req.body.list);
  }

});

app.post("/delete",function(req,res){
  //console.log(req.body.checkbox);
    const target = req.body.checkbox; // req.body.checkbox의 value값
    //[방법1]
    // Item.deleteOne({_id: target},function(err){
    //   if(err){
    //     console.log(err);
    //   }else{
    //     console.log("success");
    //     res.redirect("/");
    //   }
    // });

    //[방법2]
    Item.findByIdAndRemove(target, function(err){
      if(err){
        console.log(err);
      }else{
        console.log("success");
        res.redirect("/");
      }
    });

})

// 파라미터 다이나믹 웹사이트
app.get("/:parameter",function(req, res){
  const customListName = req.params.parameter; // parameter에 해당하는 거

  List.findOne({name: customListName}, function(err, foundList){ // 데이터 객체가 출력된다
    if(!err){
      if(!foundList){
          //Create a new List
          const list = new List({
            name: customListName,
            items: defaultItems
          });
          list.save();

          res.redirect("/"+list.name);
      }else{
          //Show an exsisting list
          res.render("list",{listTitle: customListName, newListItems: foundList.items}); ///items
      }
    }else{
      console.log(err);
    }
  });
});


app.listen(3000, function() {
  console.log("Server started on port 3000");
});
