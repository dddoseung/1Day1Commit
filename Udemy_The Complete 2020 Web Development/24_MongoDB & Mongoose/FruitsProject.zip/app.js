//jsHint esversion:6

// const MongoClient = require('mongodb').MongoClient;
// const assert = require('assert');
// Connection url
// const url = 'mongodb://localhost:27017';
//
// // Database Name
// const dbName = 'fruitsDB';
//
// // Create a new MongoClient
// const client = new MongoClient(url,{ useUnifiedTopology: true });
//
// // Connect using MongoClient
// client.connect(function(err){
//   assert.equal(null,err);
//   console.log("Connected successfully to server");
//
//   const db = client.db(dbName);
//
// insertDocuments(db,function(){ // insert됨
//     client.close();
// });
// findDocuments(db,function(){ // find(select)
//     client.close();
// });
// });

// const insertDocuments = function(db, callback) {
//   // Get the documents collection
//   const collection = db.collection('fruits');
//   // Insert some documents
//   collection.insertMany([
//     {name :"Apple",
//     score: 7,
//     review: "great fruit"},
//     {name :"Orange",
//     score: 6,
//     review: "kinda sour"},
//     {name :"Banana",
//     score: 7,
//     review: "Greate stuff"}
//   ], function(err, result) {
//     assert.equal(err, null);
//     assert.equal(3, result.result.n);
//     assert.equal(3, result.ops.length);
//     console.log("Inserted 3 documents into the collection");
//     callback(result);
//   });
// }

// const findDocuments = function(db, callback) {
//   // Get the documents collection
//   const collection = db.collection('fruits');
//   // Find some documents
//   collection.find({}).toArray(function(err, fruits) {
//     assert.equal(err, null);
//     console.log("Found the following records");
//     console.log(fruits);
//     callback(fruits);
//   });
// }

const mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/fruitsDB", { useNewUrlParser:
true },{ useUnifiedTopology: true });

//mongoose Insert

const fruitSchema = new mongoose.Schema ({
  name: { // 조건 추가
    type: String,
    required: [true, "no name"]
  },
  rating: { // 조건 추가
    type: Number,
    min: 1,
    max: 10
  },
  review: String
}); // foundation

const Fruit = mongoose.model("Fruit", fruitSchema); // Fruit 객체?로 간소화

const fruit = new Fruit({
  //name: "peach",
  rating: 1,
  review: "Oh my GOD"
});

 //fruit.save(); // insert DB to One

// const kiwi = new Fruit({
//   name: "kiwi",
//   score: 10,
//   review: "Really best"
// });
// const banana = new Fruit({
//   name: "banana",
//   score: 2,
//   review: "Too sour"
// });
// const orange = new Fruit({
//   name: "orange",
//   score: 3,
//   review: "BAD"
// });

// Fruit.insertMany([kiwi, orange, banana],function(err){
//   if(err) {
//     console.log(err);
//   }else{
//     console.log("success");
//   }
// }); // insert DB to Many



 // Fruit.updateOne({rating: 2},{name:"watermelon"},function(err,fruits){
 //   if(err){
 //     console.log(err);
 //   }else{
 //     console.log("update");
 //   }
 // }); // rating: 2의 값을 갖는 데이터의 name을 'watermelon'으로 업데이트하겠다



// Fruit.deleteOne({_id: "5fd880bf8ed63664345d21c8"},function(err){
//   if(err){
//     console.log(err);
//   }else{
//     console.log("success delete")
//   }
// });


const personSchema = new mongoose.Schema ({
  name: String,
  age: Number,
  favoriteFruit: fruitSchema // fruit 데이터를 통째로 넣을 수 있음
});

const Person = mongoose.model("Person",personSchema);

const watermelon = new Fruit({
  name: "watermelon",
  rating:10,
  review: "really nice!"
});

const person = new Person({
  name: "Amy",
  age: 8,
  favoriteFruit: watermelon // watermelon 데이터 통째로 넣기
});

 //person.save();

 Person.updateOne({name:"Amy"},{favoriteFruit: watermelon},function(err){
   if(err){
     console.log(err)
   }else{
     console.log("Success update.")
   }
 });

// Person.deleteMany({name:"John"},function(err){
//   if(err){
//     console.log(err);
//   }else{
//     console.log("success delete ALL")
//   }
// });


Fruit.find(function(err, fruits){
  if(err){
    console.log(err);
  }
  else{
    fruits.forEach(function(element){
      console.log('%s',element.name); // 데이터의 name만 출력하기
    })

    mongoose.connection.close(); // mongoDB와의 연결을 종료
  }
  // (==)
  // else{
  //   for(i=0;i<fruits.length;i++){
  //     console.log('%s',fruits[i].name);
  //   }
  // }
});
