const express = require("express");
const https = require("https");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({
  extended: true
}));

app.get("/", function(req, res) {

  res.sendFile(__dirname + "/index.html");

})

app.post("/", function(req, res) {

      const city = req.body.cityName; // index.html의 변수 cityName ex)London
      const apiKey = "643d84a7cfb15f59a62cfcc9ddd6e3e9";
      const unit = "metric";

      const url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=" + unit; // api URL

      //https.get(url[, options][, callback])
      https.get(url, function(res2) {
        console.log(res2.statusCode);
        // 응답상태 출력해줌 ex) 404 -> 오류

        res2.on("data", function(data) {
            const weatherData = JSON.parse(data);
            //JSON.parse는 string->json

            const temp = weatherData.main.temp;
            const descript = weatherData.weather[0].description;
            //piece of data -> weather[0]의 description 변수값 출력

            const icon = weatherData.weather[0].icon;
            const imgURL = "http://openweathermap.org/img/wn/" + icon + "@2x.png";

            res.write("<h1>The temperature in " + city + " is " + temp + " degrees Celcius.")
            res.write("<br>" + " It's really " + descript + ".</h1>");
            res.write("<img src=" + imgURL + ">"); // 이미지 삽입
            res.send();
          });

        });
      });

        /*
       const object = {
         name: "Seunghyun",
         favorite: "banana"
       }
        */
        // console.log(JSON.stringify(object));
        // JSON.stringify는 json->string


app.listen(3000, function() {
    console.log("Server is running on port 3000.");
})
