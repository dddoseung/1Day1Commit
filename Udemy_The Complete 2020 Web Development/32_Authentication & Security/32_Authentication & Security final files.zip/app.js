//jshint esversion:6
require('dotenv').config();
const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require("mongoose");
//const encrypt = require("mongoose-encryption"); // encryption module
//const md5 = require("md5"); // md5 Hash
// const bcrypt = require("bcrypt"); // bcrypt + salting
// const saltRounds = 10;
const session = require('express-session'); // cookies and session
const passport = require('passport');
const passportLocalMongoose = require('passport-local-mongoose');
const GoogleStrategy = require('passport-google-oauth20').Strategy; //OAuth
const findOrCreate = require('mongoose-findorcreate');
const FacebookStrategy = require('passport-facebook').Strategy;

const app = express();


app.use(express.static("public"));
app.set('view engine','ejs');
app.use(bodyParser.urlencoded({
  extended: true
}));

// 위치 중요!
app.use(session({ // initialized(set up) session
  secret:"Our little Secret.",
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize()); // initialize passport
app.use(passport.session()); // passport to manage a session

mongoose.connect("mongodb://localhost:27017/userDB",{ useUnifiedTopology: true },{useNewUrlParser: true});
mongoose.set("useCreateIndex",true);

const userSchema = new mongoose.Schema ({ // new mongoose.Schema
  email: String,
  password: String,
  googleId: String, // googleId로 find 할 수 있도록 함
  facebookId: String,
  Secret: String
});

userSchema.plugin(passportLocalMongoose); // passport-local-mongoose
userSchema.plugin(findOrCreate);

//const secret="Thisisourlittlesecret.";
//userSchema.plugin(encrypt,{secret: secret, encryptedFields: ["password"] }); //mongoose-encryption
//userSchema.plugin(encrypt,{secret: process.env.SECRET, encryptedFields: ["password"] }); //dotenv
// password를 암호화

const User = new mongoose.model("User",userSchema);

passport.use(User.createStrategy());

// use static serialize and deserialize of model for passport session support
// passport.serializeUser(User.serializeUser()); // create cookie and user's identification message
// passport.deserializeUser(User.deserializeUser()); // destroy cookie and remove message

// OAuth session serialize and deserialize
passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.findById(id, function(err, user) {
    done(err, user);
  });
});

// below serialize and deserialize
passport.use(new GoogleStrategy({
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    callbackURL: "http://localhost:3000/auth/google/secrets",
    userProfileURL: "https://www.googleapis.com/oauth2/v3/userinfo"
  },
  function(accessToken, refreshToken, profile, cb) {
    console.log(profile);

    // database에 저장된 googleId를 찾지 못하면 계속 create
    // 그러므로 userSchema에 googleId를 추가해야 함
    User.findOrCreate({ googleId: profile.id }, function (err, user) {
      // npm mongoose-findorcreate 필요
      return cb(err, user);
    });
  }
));

passport.use(new FacebookStrategy({
    clientID: process.env.FACEBOOK_CLIENT_ID,
    clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    callbackURL: "http://localhost:3000/auth/facebook/secrets"
  },
  function(accessToken, refreshToken, profile, cb) {
    User.findOrCreate({ facebookId: profile.id }, function (err, user) {
      return cb(err, user);
    });
  }
));

app.get("/",function(req, res){
  res.render("home");
});
app.get("/login",function(req, res){
  res.render("login");
});
app.get("/register",function(req, res){
  res.render("register");
});

app.get("/secrets",function(req,res){
  // if(req.isAuthenticated()){ // 권한이 있는 것을 확인하면
  //   res.render("secrets"); // rendering
  // }else{ // 없으면
  //   res.redirect("/login"); // login창
  // }

  User.find({"Secret": {$ne: null}},function(err,foundUser){
  // Secret이 exist=true인 user들을 find
    if(!err){
      if(foundUser){
        res.render("secrets", {usersWithSecrets: foundUser});
      }
    }
  })
});

app.get("/logout",function(req,res){
  req.logout();
  res.redirect("/");
});

app.get('/auth/google', // 구글 로그인 요청
  passport.authenticate('google', { scope: ["profile"] }));

app.get('/auth/google/secrets', // 구글 로그인 권한을 받은 후 callback
  passport.authenticate('google', { failureRedirect: "/login" }),
  function(req, res) {
    // Successful authentication, redirect home.
    res.redirect('/secrets');
  });

app.get('/auth/facebook',
  passport.authenticate('facebook'));

app.get('/auth/facebook/secrets',
  passport.authenticate('facebook', { failureRedirect: "/login" }),
  function(req, res) {
    // Successful authentication, redirect home.
    res.redirect('/secrets');
  });

  app.get("/submit",function(req,res){
    if(req.isAuthenticated()){
      res.render("submit");
    }else{
      res.redirect("/login");
    }
  })

app.post("/register",function(req, res){
  // bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
  //     // Store hash in your password DB.
  //     const newUser = new User({
  //       email: req.body.username,
  //       password: hash //
  //     });
  //
  //     newUser.save(function(err){
  //       if(!err){
  //         res.render("secrets");
  //       }
  //     });
  // });
  User.register({username: req.body.username}, req.body.password, function(err, user){
    if(err){
      console.log(err);
      res.redirect("/register");
    }else{
      passport.authenticate("local")(req,res,function(){ // 권한 부여 받으면
        res.redirect("/secrets");
      })
    }
  })

});

app.post("/login",function(req,res){
  // const userEmail = req.body.username;
  // const userPassword = req.body.password;
  //
  // User.findOne({email: userEmail},function(err,foundUser){
  //   if(!err){
  //     if(foundUser){
  //       // if(foundUser.password === userPassword){
  //       //   res.render("secrets");
  //       // }
  //       bcrypt.compare(userPassword, foundUser.hash,function(err,result) {
  //           if(result==true){
  //             res.render("secrets");
  //           };
  //       });
  //     }
  //   }
  // });

  const user = new User({
    username: req.body.username,
    password: req.body.password
  });

  req.login(user, function(err){
    if(err){
      console.log(err);
    }else{
      passport.authenticate("local");
      res.redirect("/secrets");
    }
  })
});

app.post("/submit",function(req,res){
  const submittedSecret = req.body.secret;

  User.findById(req.user.id, function(err, foundUser){ // 로그인 된 해당 user의 id를 찾아서
      if(!err){
        if(foundUser){
          foundUser.Secret=submittedSecret;
          foundUser.save(function(){
            res.redirect("/secrets");
          })
        }
      }
  });
})

app.listen(3000,function(){
  console.log("success connect localhost 3000");
})
