const express = require('express');
const bodyParser=require('body-parser'); // body-parser 모듈 호출

const app = express();
app.use(bodyParser.urlencoded({extended: true})); // body-parser

const port = 3000;

app.get("/", function(req, res){
  res.sendFile(__dirname+"/"+"index.html");
});

app.post("/", function(req, res){
  var num1 = Number(req.body.n1); // Number()로 하면 숫자 변수가 됨
  var num2 = Number(req.body.n2);
                  // n1과 n2는 index.html의 input name의 해당함
  var result = num1+num2;
  res.send("<em>The result of the calculation is "+ result+"<em>");
})


app.get("/bmicalculator", function(req, res){
  res.sendFile(__dirname+"/bmiCalculator.html");
})

app.post("/bmicalculator", function(req, res){
  var w= Number(req.body.w);
  var h= Number(req.body.h);

  var n = w/(h*h);

  res.send("Your BMI is "+ parseFloat(n).toFixed(2));
  // 소수점 둘째자리까지 나타내기
})


app.listen(port, function(){
  console.log("Server started on port 3000");
});
