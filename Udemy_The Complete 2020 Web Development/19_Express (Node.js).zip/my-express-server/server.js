const express = require("express");
const app = express();
const port = 3000;

// 'above' listen method
app.get("/",function(req, res){ // "/"->루트 URL(/) localhost:3000
  res.send("<h1>Hello, World!</h1>");
});

app.get("/contact", function(req,res){ // localhost:3000/contact
  res.send("Contact me at: tmdgus@naver.com");
});

app.get("/about", function(req,res){ // localhost:3000/about
  res.send("Hi, I am SeungHyun. I love beer!");
});

app.listen(port, function(){
  console.log("Server started on port 3000")
}); // listen to port any http request (3000번 포트에서 연결을 청취)
