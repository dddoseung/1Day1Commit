const express = require('express');
const bodyParser = require('body-parser');
const datejs = require(__dirname + "/date.js"); // return day;

const app = express();

app.use(express.static("public"));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.set('view engine', 'ejs'); // 꼭 view engine

let items=["Buy Food","Cook Food","Eat Food"];
let workItems=[];

app.get("/", function(req, res) {

  let day=datejs.getDate();

  // "list" is list.ejs (ejs rendering)
  res.render("list", {kindOfDay: day, newListItems: items});
});

app.post("/", function(request,response) {
  if(request.body.newButton === "Work"){
    workItem=request.body.newItem;
    workItems.push(workItem);
    response.redirect("/work"); // app.get("/work")으로 돌아간다

  }else{
    item = request.body.newItem;
    // res.render("list", {newListItem: item}); render를 두 번 하면 오류 난다
    items.push(item);
    response.redirect("/"); // app.get("/")으로 돌아간다
  }

});

app.get("/work",function(req,res){
  res.render("list",{kindOfDay: "Work List", newListItems: workItems});
})

app.get("/about", function(req,res){
  res.render("about");
})

app.listen(3000, function() {
  console.log("server port 3000");
});
